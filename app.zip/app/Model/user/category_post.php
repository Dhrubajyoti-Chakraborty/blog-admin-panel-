<?php

namespace app\Model\user;


use Illuminate\Database\Eloquent\Model;

class category_post extends Model
{
    //
}
